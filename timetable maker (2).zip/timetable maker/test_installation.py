import sys
import importlib
import subprocess

def check_package(package_name):
    """Check if a package is installed"""
    try:
        importlib.import_module(package_name)
        return True
    except ImportError:
        return False

def test_installation():
    """Test if all required packages are installed"""
    required_packages = [
        'streamlit',
        'geocoder',
        'speech_recognition',
        'pyaudio',
        'gtts',
        'pygame',
        'numpy',
        'requests'
    ]
    
    print("🔍 Testing installation...")
    print("=" * 50)
    
    all_good = True
    
    for package in required_packages:
        if check_package(package):
            print(f"✅ {package}")
        else:
            print(f"❌ {package} - NOT INSTALLED")
            all_good = False
    
    print("=" * 50)
    
    if all_good:
        print("🎉 All packages are installed correctly!")
        print("You can now run: streamlit run panic_button_app.py")
    else:
        print("❌ Some packages are missing.")
        print("Run: pip install -r requirements.txt")
    
    return all_good

if __name__ == "__main__":
    test_installation()
