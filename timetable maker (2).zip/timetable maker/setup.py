import subprocess
import sys
import os

def install_requirements():
    """Install required packages"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("✅ All dependencies installed successfully!")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error installing dependencies: {e}")
        print("Please install manually using: pip install -r requirements.txt")

def check_python_version():
    """Check if Python version is compatible"""
    if sys.version_info < (3, 7):
        print("❌ Python 3.7 or higher is required")
        return False
    print("✅ Python version is compatible")
    return True

if __name__ == "__main__":
    print("🚨 Setting up Emergency Panic Button App...")
    print("Checking Python version...")
    
    if check_python_version():
        print("Installing dependencies...")
        install_requirements()
        print("\n🎉 Setup complete! Run the app with: streamlit run panic_button_app.py")
