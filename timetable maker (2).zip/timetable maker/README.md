# 🚨 Emergency Panic Button App

A Streamlit-based emergency panic button application that provides instant location sharing and voice recording capabilities for emergency situations.

## Features

- 🔴 **Round Red Panic Button** - Large, easily accessible emergency button
- 📍 **GPS Location** - Automatically fetches and displays current coordinates
- 📤 **Emergency Alerts** - Shares location with police and women helpline numbers
- 🎤 **Voice Recording** - Records 30-second audio clips
- 🆘 **Keyword Detection** - Detects "help" keyword in voice recordings
- 📱 **Multi-contact Support** - Sends alerts to multiple emergency contacts

## Installation

1. **Install Python 3.7+** if not already installed

2. **Clone or download this project**

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
   
   Or run the setup script:
   ```bash
   python setup.py
   ```

4. **Run the application**:
   ```bash
   streamlit run panic_button_app.py
   ```

## Usage

1. **Open the app** in your browser (usually at `http://localhost:8501`)

2. **Press the red PANIC button** when in emergency

3. **The app will automatically**:
   - Get your current GPS location
   - Share location with emergency contacts
   - Start recording your voice for 30 seconds
   - Transcribe the recording
   - Send alerts if "help" keyword is detected

## Configuration

Edit `config.json` to customize:
- Emergency contact numbers
- Recording duration
- Help keywords
- Location timeout settings

## Emergency Contacts

Default contacts include:
- Police Helpline: 100
- Women Helpline: 1091
- Fire Department: 101
- Ambulance: 108

## Troubleshooting

### Common Issues

1. **PyAudio installation issues**:
   ```bash
   pip install pipwin
   pipwin install pyaudio
   ```

2. **Permission issues**:
   - Allow microphone access when prompted
   - Allow location access in browser

3. **Geocoder issues**:
   - Ensure internet connection for location services

## Safety Note

This app is for emergency situations. Test the app in a safe environment before actual use. The emergency contact numbers are for India - update them according to your country/region.

## Development

To add new features or modify the app:

1. Edit `panic_button_app.py` for UI changes
2. Update `config.json` for contact/setting changes
3. Test thoroughly in a safe environment

## Support

For issues or questions, please check the troubleshooting section or contact the developer.
