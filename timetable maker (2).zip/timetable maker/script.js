// DOM elements
const panicButton = document.getElementById('panicButton');
const statusSection = document.getElementById('statusSection');
const emergencySection = document.getElementById('emergencySection');

// Global variables
let mediaRecorder = null;
let audioChunks = [];
let recognition = null;
let isRecording = false;

// Event listener for panic button
panicButton.addEventListener('click', handlePanicButtonClick);

async function handlePanicButtonClick() {
    if (isRecording) return;
    
    isRecording = true;
    panicButton.disabled = true;
    panicButton.textContent = 'Recording...';
    
    // Clear previous content
    statusSection.innerHTML = '';
    emergencySection.innerHTML = '';
    
    // Show initial status card
    showStatusCard();
    
    try {
        // Start microphone recording
        await startRecording();
        
        // Start speech recognition
        startSpeechRecognition();
        
    } catch (error) {
        console.error('Error:', error);
        resetPanicButton();
    }
}

function showStatusCard() {
    const statusCard = document.createElement('div');
    statusCard.className = 'status-card';
    statusCard.innerHTML = `
        <h3>Emergency Status</h3>
        <div class="status-item">
            <input type="checkbox" id="location" checked disabled>
            <label for="location">Location shared</label>
        </div>
        <div class="status-item">
            <input type="checkbox" id="police" checked disabled>
            <label for="police">Police helpline numbers informed</label>
        </div>
        <div class="status-item">
            <input type="checkbox" id="recording" checked disabled>
            <label for="recording">Live recording in progress</label>
        </div>
    `;
    statusSection.appendChild(statusCard);
}

async function startRecording() {
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        
        mediaRecorder = new MediaRecorder(stream);
        audioChunks = [];
        
        mediaRecorder.ondataavailable = (event) => {
            audioChunks.push(event.data);
        };
        
        mediaRecorder.onstop = () => {
            // Recording stopped, audio data is in audioChunks
            console.log('Recording stopped, audio chunks:', audioChunks.length);
        };
        
        mediaRecorder.start();
        console.log('Recording started');
        
    } catch (error) {
        console.error('Error accessing microphone:', error);
        throw error;
    }
}

function startSpeechRecognition() {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
        console.log('Speech recognition not supported');
        return;
    }
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';
    
    // Update the transcript display in the status section
    recognition.onresult = (event) => {
        const transcript = Array.from(event.results)
            .map(result => result[0])
            .map(result => result.transcript)
            .join('');

        console.log('Transcript:', transcript);

        // Display the transcript on the screen
        const transcriptDisplay = document.createElement('p');
        transcriptDisplay.textContent = `Recognized Text: ${transcript}`;
        statusSection.appendChild(transcriptDisplay);

        // Check for "HELP" (case-insensitive)
        if (transcript.toLowerCase().includes('help')) {
            triggerEmergency();
        }
    };
    
    recognition.onerror = (event) => {
        console.error('Speech recognition error:', event.error);
    };
    
    recognition.onend = () => {
        console.log('Speech recognition ended');
    };
    
    recognition.start();
    console.log('Speech recognition started');
    
    // Stop recording after 30 seconds
    setTimeout(() => {
        stopRecording();
    }, 30000);
}

function triggerEmergency() {
    stopRecording();
    showEmergencyCard();
}

function stopRecording() {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
        mediaRecorder.stop();
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
    }
    
    if (recognition) {
        recognition.stop();
    }
    
    resetPanicButton();
}

function resetPanicButton() {
    isRecording = false;
    panicButton.disabled = false;
    panicButton.textContent = 'Panic';
}

function showEmergencyCard() {
    const emergencyCard = document.createElement('div');
    emergencyCard.className = 'emergency-card';
    emergencyCard.innerHTML = `
        <h3>🔴 Emergency Triggered!</h3>
        <div class="status-card" style="margin: 15px 0;">
            <h3>Emergency Status</h3>
            <div class="status-item">
                <input type="checkbox" id="location2" checked disabled>
                <label for="location2">Location shared</label>
            </div>
            <div class="status-item">
                <input type="checkbox" id="police2" checked disabled>
                <label for="police2">Police helpline numbers informed</label>
            </div>
            <div class="status-item">
                <input type="checkbox" id="recording2" checked disabled>
                <label for="recording2">Live recording in progress</label>
            </div>
        </div>
        <p class="emergency-message">SOS message sent to emergency contacts with 30-sec recording attached.</p>
        <div class="emergency-contact">📩 Message sent to Police Helpline 100</div>
        <div class="emergency-contact">📩 Message sent to Emergency Contact (Mom - 9876543210)</div>
    `;
    emergencySection.appendChild(emergencyCard);
}

// Handle browser compatibility
if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    console.warn('getUserMedia not supported');
    panicButton.addEventListener('click', () => {
        alert('Microphone access is not supported in this browser. Please use a modern browser.');
    });
}



