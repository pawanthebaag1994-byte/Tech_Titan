import streamlit as st
import geocoder
import speech_recognition as sr
import threading
import time
import json
import requests
from datetime import datetime
import pyaudio
import wave
import os
from gtts import gTTS
import pygame
import numpy as np
from streamlit_autorefresh import st_autorefresh

# Page configuration
st.set_page_config(
    page_title="Emergency Panic Button",
    page_icon="🚨",
    layout="centered",
    initial_sidebar_state="collapsed"
)

# Custom CSS for styling
st.markdown("""
<style>
    .panic-button {
        width: 200px;
        height: 200px;
        border-radius: 50%;
        background-color: #ff0000;
        color: white;
        font-size: 24px;
        font-weight: bold;
        border: none;
        cursor: pointer;
        box-shadow: 0 8px 16px rgba(0,0,0,0.3);
        transition: all 0.3s ease;
        margin: 20px auto;
        display: block;
    }
    
    .panic-button:hover {
        background-color: #cc0000;
        transform: scale(1.05);
    }
    
    .panic-button:active {
        transform: scale(0.95);
    }
    
    .emergency-message {
        background-color: #ffebee;
        border-left: 5px solid #f44336;
        padding: 15px;
        margin: 10px 0;
        border-radius: 5px;
    }
    
    .alert-animation {
        animation: pulse 1s infinite;
    }
    
    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.5; }
        100% { opacity: 1; }
    }
    
    .location-info {
        background-color: #e3f2fd;
        padding: 15px;
        border-radius: 10px;
        margin: 10px 0;
    }
    
    .recording-status {
        background-color: #fff3e0;
        padding: 15px;
        border-radius: 10px;
        margin: 10px 0;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'panic_pressed' not in st.session_state:
    st.session_state.panic_pressed = False
if 'location' not in st.session_state:
    st.session_state.location = None
if 'recording_complete' not in st.session_state:
    st.session_state.recording_complete = False
if 'transcript' not in st.session_state:
    st.session_state.transcript = ""
if 'help_detected' not in st.session_state:
    st.session_state.help_detected = False
if 'emergency_contacts' not in st.session_state:
    st.session_state.emergency_contacts = [
        {"name": "Police Helpline", "number": "100"},
        {"name": "Women Helpline", "number": "1091"},
        {"name": "Emergency Contact 1", "number": "+911234567890"},
        {"name": "Emergency Contact 2", "number": "+919876543210"}
    ]

def get_current_location():
    """Get current GPS coordinates"""
    try:
        g = geocoder.ip('me')
        if g.latlng:
            return {
                "latitude": g.latlng[0],
                "longitude": g.latlng[1],
                "address": g.address
            }
    except Exception as e:
        st.error(f"Error getting location: {str(e)}")
        return None

def record_audio(duration=30):
    """Record audio for specified duration"""
    try:
        CHUNK = 1024
        FORMAT = pyaudio.paInt16
        CHANNELS = 1
        RATE = 44100
        
        p = pyaudio.PyAudio()
        stream = p.open(format=FORMAT,
                       channels=CHANNELS,
                       rate=RATE,
                       input=True,
                       frames_per_buffer=CHUNK)
        
        frames = []
        for i in range(0, int(RATE / CHUNK * duration)):
            data = stream.read(CHUNK)
            frames.append(data)
        
        stream.stop_stream()
        stream.close()
        p.terminate()
        
        # Save audio file
        filename = f"emergency_recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav"
        wf = wave.open(filename, 'wb')
        wf.setnchannels(CHANNELS)
        wf.setsampwidth(p.get_sample_size(FORMAT))
        wf.setframerate(RATE)
        wf.writeframes(b''.join(frames))
        wf.close()
        
        return filename
    except Exception as e:
        st.error(f"Error recording audio: {str(e)}")
        return None

def transcribe_audio(audio_file):
    """Convert speech to text"""
    try:
        r = sr.Recognizer()
        with sr.AudioFile(audio_file) as source:
            audio = r.record(source)
        
        text = r.recognize_google(audio)
        return text
    except Exception as e:
        return f"Could not transcribe audio: {str(e)}"

def send_emergency_alert(location, transcript, contacts):
    """Send emergency alerts to contacts"""
    messages = []
    
    for contact in contacts:
        message = f"""
        🚨 EMERGENCY ALERT 🚨
        
        Location: {location.get('address', 'Unknown')}
        Coordinates: {location.get('latitude')}, {location.get('longitude')}
        Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        
        Voice Message: {transcript}
        
        This is an automated emergency alert from the Panic Button app.
        """
        
        # In a real app, this would send SMS/WhatsApp
        messages.append({
            "contact": contact["name"],
            "message": message
        })
    
    return messages

def main():
    st.title("🚨 Emergency Panic Button")
    st.markdown("### Press the red button below in case of emergency")
    
    # Panic Button
    if st.button("🚨 PANIC", key="panic_btn", help="Press in case of emergency"):
        st.session_state.panic_pressed = True
        
    if st.session_state.panic_pressed:
        st.markdown("---")
        
        # 1. GPS Location
        with st.spinner("Getting your location..."):
            location = get_current_location()
            st.session_state.location = location
        
        if location:
            st.markdown('<div class="location-info">', unsafe_allow_html=True)
            st.markdown("### 📍 GPS Location")
            st.write(f"**Coordinates:** {location['latitude']}, {location['longitude']}")
            st.write(f"**Address:** {location['address']}")
            st.markdown('</div>', unsafe_allow_html=True)
        
        # 2. Live Location Shared
        st.markdown('<div class="emergency-message">', unsafe_allow_html=True)
        st.markdown("### 📤 Location Shared")
        st.write("Your live location has been shared to:")
        for contact in st.session_state.emergency_contacts:
            st.write(f"- {contact['name']}: {contact['number']}")
        st.markdown('</div>', unsafe_allow_html=True)
        
        # 3. Voice Recording
        st.markdown('<div class="recording-status">', unsafe_allow_html=True)
        st.markdown("### 🎤 Voice Recording")
        
        if not st.session_state.recording_complete:
            with st.spinner("Recording for 30 seconds..."):
                audio_file = record_audio(30)
                
                if audio_file:
                    st.success("Recording completed!")
                    st.session_state.recording_complete = True
                    
                    # Transcribe audio
                    with st.spinner("Transcribing audio..."):
                        transcript = transcribe_audio(audio_file)
                        st.session_state.transcript = transcript
                        
                        # Check for help keyword
                        if "help" in transcript.lower():
                            st.session_state.help_detected = True
                            st.markdown('<div class="alert-animation">', unsafe_allow_html=True)
                            st.error("🆘 HELP KEYWORD DETECTED! Emergency services have been notified!")
                            st.markdown('</div>', unsafe_allow_html=True)
                            
                            # Send alerts
                            messages = send_emergency_alert(
                                st.session_state.location,
                                st.session_state.transcript,
                                st.session_state.emergency_contacts
                            )
                            
                            st.markdown("### 📱 Emergency Alerts Sent")
                            for msg in messages:
                                st.info(f"Message sent to {msg['contact']}")
                        else:
                            st.info("No help keyword detected. Recording saved for reference.")
        
        if st.session_state.transcript:
            st.markdown("### 📝 Voice Transcript")
            st.write(st.session_state.transcript)
    
    # Sidebar for emergency contacts
    with st.sidebar:
        st.markdown("### Emergency Contacts")
        for contact in st.session_state.emergency_contacts:
            st.write(f"**{contact['name']}:** {contact['number']}")
        
        if st.button("Reset App"):
            for key in st.session_state.keys():
                del st.session_state[key]
            st.experimental_rerun()

if __name__ == "__main__":
    main()
